<?php
include 'DB.php';
$db = new DB();
$tblName = 'client_details';
if(isset($_REQUEST['type']) && !empty($_REQUEST['type'])){
    $type = $_REQUEST['type'];
    switch($type){
        case "view":
            $records = $db->getRows($tblName);
            if($records){
                $data['records'] = $db->getRows($tblName);
                $data['status'] = 'OK';
            }else{
                $data['records'] = array();
                $data['status'] = 'ERR';
            }
            echo json_encode($data);
            break;
        case "add":
            if(!empty($_POST['data'])){
                $userData = array(
                    'name' => $_POST['data']['name'],
					'relative_name' => $_POST['data']['relative_name'],
					'age' => $_POST['data']['age'],
					'aadhar_no' => $_POST['data']['aadhar_no'],
					'address' => $_POST['data']['address'],
					'payment_mode' => $_POST['data']['payment_mode'],
				    'date_of_payment' => $_POST['data']['date_of_payment'],
				    'total_amount' => $_POST['data']['total_amount'],
				    'paid' => $_POST['data']['paid'],
					'balance_amount' => $_POST['data']['balance_amount'],
					'phone' => $_POST['data']['phone']
                );
                $insert = $db->insert($tblName,$userData);
                if($insert){
                    $data['data'] = $insert;
                    $data['status'] = 'OK';
                    $data['msg'] = 'User data has been added successfully.';
                }else{
                    $data['status'] = 'ERR';
                    $data['msg'] = 'Some problem occurred, please try again.';
                }
            }else{
                $data['status'] = 'ERR';
                $data['msg'] = 'Some problem occurred, please try again.';
            }
            echo json_encode($data);
            break;
        case "edit":
            if(!empty($_POST['data'])){
                $userData = array(
                    'name' => $_POST['data']['name'],
					'relative_name' => $_POST['data']['relative_name'],
					'age' => $_POST['data']['age'],
					'aadhar_no' => $_POST['data']['aadhar_no'],
					'address' => $_POST['data']['address'],
					'payment_mode' => $_POST['data']['payment_mode'],
				    'date_of_payment' => $_POST['data']['date_of_payment'],
				    'total_amount' => $_POST['data']['total_amount'],
				    'paid' => $_POST['data']['paid'],
					'balance_amount' => $_POST['data']['balance_amount'],
					
					
					
					
					
                   
                    'phone' => $_POST['data']['phone']
                );
                $condition = array('id' => $_POST['data']['id']);
                $update = $db->update($tblName,$userData,$condition);
                if($update){
                    $data['status'] = 'OK';
                    $data['msg'] = 'User data has been updated successfully.';
                }else{
                    $data['status'] = 'ERR';
                    $data['msg'] = 'Some problem occurred, please try again.';
                }
            }else{
                $data['status'] = 'ERR';
                $data['msg'] = 'Some problem occurred, please try again.';
            }
            echo json_encode($data);
            break;
        case "delete":
            if(!empty($_POST['id'])){
                $condition = array('id' => $_POST['id']);
                $delete = $db->delete($tblName,$condition);
                if($delete){
                    $data['status'] = 'OK';
                    $data['msg'] = 'User data has been deleted successfully.';
                }else{
                    $data['status'] = 'ERR';
                    $data['msg'] = 'Some problem occurred, please try again.';
                }
            }else{
                $data['status'] = 'ERR';
                $data['msg'] = 'Some problem occurred, please try again.';
            }
            echo json_encode($data);
            break;
        default:
            echo '{"status":"INVALID"}';
    }
}