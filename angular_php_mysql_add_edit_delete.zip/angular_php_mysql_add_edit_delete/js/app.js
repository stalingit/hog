// define application
angular.module("crudApp", [])
.controller("userController", function($scope,$http){
    $scope.users = [];
    $scope.tempUserData = {};
    // function to get records from the database
    $scope.getRecords = function(){
        $http.get('action.php', {
            params:{
                'type':'view'
            }
        }).success(function(response){
            if(response.status == 'OK'){
                $scope.users = response.records;
            }
        });
    };
    
    // function to insert or update user data to the database
    $scope.saveUser = function(type){
        var data = $.param({
            'data':$scope.tempUserData,
            'type':type
        });
        var config = {
            headers : {
                'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
            }
        };
        $http.post("action.php", data, config).success(function(response){
            if(response.status == 'OK'){
                if(type == 'edit'){
                    $scope.users[$scope.index].id = $scope.tempUserData.id;
                    $scope.users[$scope.index].name = $scope.tempUserData.name;
					$scope.users[$scope.index].relative_name = $scope.tempUserData.relative_name;
					$scope.users[$scope.index].age = $scope.tempUserData.age;
					$scope.users[$scope.index].aadhar_no = $scope.tempUserData.aadhar_no;
				    $scope.users[$scope.index].address = $scope.tempUserData.address;
				    $scope.users[$scope.index].payment_mode = $scope.tempUserData.payment_mode;
	     	     	$scope.users[$scope.index].date_of_payment = $scope.tempUserData.date_of_payment;
					$scope.users[$scope.index].total_amount = $scope.tempUserData.total_amount;
					$scope.users[$scope.index].paid = $scope.tempUserData.paid;
				    $scope.users[$scope.index].balance_amount = $scope.tempUserData.balance_amount;
					
					
                    $scope.users[$scope.index].email = $scope.tempUserData.email;
                    $scope.users[$scope.index].phone = $scope.tempUserData.phone;
                    $scope.users[$scope.index].created = $scope.tempUserData.created;
                }else{
                    $scope.users.push({
                        id:response.data.id,
                        name:response.data.name,
						relative_name:response.data.relative_name,
						age:response.data.age,
						aadhar_no:response.data.aadhar_no,
						address:response.data.address,
			            payment_mode:response.data.payment_mode,
						date_of_payment:response.data.date_of_payment,
						total_amount:response.data.total_amount,
						paid:response.data.paid,
						balance_amount:response.data.balance_amount,
						
						
						
						
						
						
                        email:response.data.email,
                        phone:response.data.phone,
                        created:response.data.created
                    });
                    
                }
                $scope.userForm.$setPristine();
                $scope.tempUserData = {};
                $('.formData').slideUp();
                $scope.messageSuccess(response.msg);
            }else{
                $scope.messageError(response.msg);
            }
        });
    };
    
    // function to add user data
    $scope.addUser = function(){
        $scope.saveUser('add');
    };
    
    // function to edit user data
    $scope.editUser = function(user){
        $scope.tempUserData = {
            id:user.id,
            name:user.name,
			relative_name:user.relative_name,
			age:user.age,
			aadhar_no:user.aadhar_no,
			address:user.address,
		    payment_mode:user.payment_mode,
		    date_of_payment:user.date_of_payment,
		    total_amount:user.total_amount,
		    paid:user.paid,
			balance_amount:user.balance_amount,
			
            email:user.email,
            phone:user.phone,
            created:user.created
        };
        $scope.index = $scope.users.indexOf(user);
        $('.formData').slideDown();
    };
    
    // function to update user data
    $scope.updateUser = function(){
        $scope.saveUser('edit');
    };
    
    // function to delete user data from the database
    $scope.deleteUser = function(user){
        var conf = confirm('Are you sure to delete the user?');
        if(conf === true){
            var data = $.param({
                'id': user.id,
                'type':'delete'    
            });
            var config = {
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }    
            };
            $http.post("action.php",data,config).success(function(response){
                if(response.status == 'OK'){
                    var index = $scope.users.indexOf(user);
                    $scope.users.splice(index,1);
                    $scope.messageSuccess(response.msg);
                }else{
                    $scope.messageError(response.msg);
                }
            });
        }
    };
    
    // function to display success message
    $scope.messageSuccess = function(msg){
        $('.alert-success > p').html(msg);
        $('.alert-success').show();
        $('.alert-success').delay(5000).slideUp(function(){
            $('.alert-success > p').html('');
        });
    };
    
    // function to display error message
    $scope.messageError = function(msg){
        $('.alert-danger > p').html(msg);
        $('.alert-danger').show();
        $('.alert-danger').delay(5000).slideUp(function(){
            $('.alert-danger > p').html('');
        });
    };
});