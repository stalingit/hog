<!DOCTYPE html>
<html>
<head>
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
<!-- <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>-->



<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.10.4/themes/ui-lightness/jquery-ui.css">
<script src = "https://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
 <script src = "https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
<script src="js/app.js"></script>
<script>
         $(function() {
            $( "#datepicker_id" ).datepicker({
            	minDate: 0,
            	dateFormat: 'yy-mm-dd'
            });
           // $( "#datepicker_id" ).datepicker('setDate', new Date());

         });

function edValueKeyPress(){	 
	 var get_total_amount =$( "#total_amount" ).val(); 
	 var interest = $( "#sel1" ).val();
	 var interest_amount = get_total_amount*(interest/100);
	 var balance_amount = get_total_amount - interest_amount;
	 $( "#balance_amount_id" ).val(balance_amount);



}


      </script> 
</head>
<body ng-app="crudApp">
<div class="container" ng-controller="userController" ng-init="getRecords()">
    <div class="row">
        <div class="panel panel-default users-content">
            <div class="panel-heading">Users <a href="javascript:void(0);" class="glyphicon glyphicon-plus" onclick="$('.formData').slideToggle();"></a></div>
            <div class="alert alert-danger none"><p></p></div>
            <div class="alert alert-success none"><p></p></div>
            <div class="panel-body none formData">
                <form class="form" name="userForm">
                    <div class="form-group">
                        <label>Name</label>
                        <input type="text" class="form-control" name="name" ng-model="tempUserData.name"/>
                    </div>
					  <div class="form-group">
                        <label>Phone No</label>
                        <input type="text" class="form-control" name="phone" ng-model="tempUserData.phone"/>
                    </div>
					
					 <div class="form-group">
                        <label>Spouse Name/Guardian Name</label>
                        <input type="text" class="form-control" name="relative_name" ng-model="tempUserData.relative_name"/>
                    </div>
					<div class="form-group">
                        <label>Age</label>
                        <input type="text" class="form-control" name="age" ng-model="tempUserData.age"/>
                    </div>
					
					
					
					 <div class="form-group">
                        <label>Adhar No</label>
                        <input type="text" class="form-control" name="aadhar_no" ng-model="tempUserData.aadhar_no "/>
                    </div>
					<div class="form-group">
                        <label>Address</label>
                       
						  <textarea class="form-control" rows="5" id="address" name="address" ng-model="tempUserData.address "></textarea>
                    </div>
					<div class="form-group">
                        <label>Payment Mode</label>
                       <!--  <input type="text" class="form-control" name="payment_mode"  ng-model="tempUserData.payment_mode "/>-->
						
						<div class="radio">
							<label><input type="radio" name="payment_mode" ng-model="tempUserData.payment_mode" value="Daily" >Daily</label>
						</div>
						<div class="radio">
						  <label><input type="radio" name="payment_mode" ng-model="tempUserData.payment_mode" value="Weekly">Weekly</label>
						</div>
						<div class="radio ">
						  <label><input type="radio" name="payment_mode" ng-model="tempUserData.payment_mode" value="Monthly">Monthly</label>
						</div>
						
						
						
						
						
						
						
						
                    </div>
					<div class="form-group">
                        <label>Date of payment</label>
                        <input type="text" class="form-control" name="date_of_payment" id="datepicker_id" ng-model="tempUserData.date_of_payment "/>
                    </div>
					<div class="form-group">
                        <label>Total Amount</label>
                        <input type="text" class="form-control" name="total_amount" ng-model="tempUserData.total_amount " id="total_amount"/>
                    </div>
					
					<div class="form-group">
						<label for="sel1">Interest</label>
						<select class="form-control" id="sel1" name="interest" ng-model="tempUserData.interest ">

						<?php	
							for($i=1;$i<=10;$i++)
								{
								echo "<option value='$i'>$i%</option>";
						 		}
						?>
						
					  </select>
                   </div>
					
					
					
					
					
					<div class="form-group">
                        <label>Balance Amount</label>
                        <input type="text" class="form-control" name="balance_amount" ng-model="tempUserData.balance_amount " onKeyPress="edValueKeyPress()" onKeyUp="edValueKeyPress()" id="balance_amount_id"/>
                    </div>
					<div class="form-group" style="display:none">
                        <label>Paid</label>
                        <input type="hidden" class="form-control" name="paid" ng-model="tempUserData.paid " value="1000"/>
                    </div>
					
                    
                    
                    <a href="javascript:void(0);" class="btn btn-warning" onclick="$('.formData').slideUp();">Cancel</a>
                    <a href="javascript:void(0);" class="btn btn-success" ng-hide="tempUserData.id" ng-click="addUser()">Add User</a>
                    <a href="javascript:void(0);" class="btn btn-success" ng-hide="!tempUserData.id" ng-click="updateUser()">Update User</a>
                </form>
            </div>

            <table class="table table-striped">
                <tr>
                    <th width="5%"> {{user.totalItems}}</th>
                    <th>Name</th>
					<th>Contact No</th>
					<th>Relative name </th>
					<th>Age </th>
					<th>Adhar No </th>
					<th>Address  </th>
					<th>Payment Mode  </th>
					<th>Date of payment</th>
					<th>Total Amount  </th>
				<!-- 	<th>Paid </th>-->
					<th>Balance Amount</th>
                   
                   
                 
					
                    <th width="10%"></th>
                </tr>
                <tr ng-repeat="user in users | orderBy:'-id'">
                    <td>{{$index + 1}}</td>
                    <td>{{user.name}}</td>
                  
                    <td>{{user.phone}}</td>
                    <td>{{user.relative_name}}</td>
					 <td>{{user.age}}</td>
					  <td>{{user.aadhar_no}}</td>
					   <td>{{user.address}}</td>
					    <td>


					    {{user.payment_mode}}



					</td>
						 <td>{{user.date_of_payment}}</td>
						  <td>{{user.total_amount}}</td>
						  <!-- <td>{{user.paid}}</td>-->
						    <td>{{user.balance_amount}}</td>
							
                    <td>
                        <a href="javascript:void(0);" class="glyphicon glyphicon-edit" ng-click="editUser(user)"></a>
                        <a href="javascript:void(0);" class="glyphicon glyphicon-trash" ng-click="deleteUser(user)"></a>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>

</body>
</html>